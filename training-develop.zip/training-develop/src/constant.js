const adminRole = 1;
const memberRole = 0;

module.exports = { adminRole, memberRole };