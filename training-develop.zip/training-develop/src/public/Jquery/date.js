$( function() {
    $( "#bDay" ).datepicker({ dateFormat: 'dd/mm/yy' }).val();
} );